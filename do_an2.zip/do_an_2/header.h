/*
 * header.h
 *
 *  Created on: Oct 21, 2017
 *      Author: Tung
 */

#ifndef HEADER_H_
#define HEADER_H_
//#define DEBUG
typedef enum {
    CMD ,
    DATA ,
} DataType;
String data_resp;
#define caiso
typedef struct{
   String year;
   String month;
   String date;
   String hour;
   String minute;
   String sec;
}SysTime;
typedef struct{
  bool State_gps;     /*!< trang thai gps 1 = co tin hieu, 0 = mat tin hieu */
  SysTime time_gps;   /*!< time gps  */
  String Lat;     /*!< vi do */
  String Lng;     /*!< kinh do */
  float SpeedGPS;     /*!< Toc do GPS */
  float OrGPS;      /*!< Huong GPS 360 do */
}GPS_T;     /*!< cau truc du lieu hanh trinh */
//#define DEBUG

#endif /* HEADER_H_ */
