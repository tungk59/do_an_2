#include "Energia.h"

#line 1 "C:/Users/MYPC/workspace_v7/do_an_2/do_an_2.ino"
#include "header.h"
void serialEventRun(void);
void setup();
void loop();
void Send_cmd(String cmd, String &resp);
String get_resp();
int8_t sendATcommand(char* ATcommand, char* expected_answer, unsigned int timeout);
void sim808_init(void);
void convert_gps(GPS_T * gps_data,char* data);
String conv_TimeGps(GPS_T *gps_data);
void get_GPS(void);
void sendSMS(char* phone,String SMS);
void serialEvent();

#line 2
void serialEventRun(void) {
  if (Serial.available()) serialEvent();

}


GPS_T g_gps_data = {false,0,0,0,0};


char* phone_number="0966406225";
void setup() {
  

    Serial1.begin(9600);
    Serial.begin(9600);
    sim808_init();
}

void loop() {
  
  
}


void Send_cmd(String cmd, String &resp)
{
    resp="";
    Serial1.println(cmd);
    delay(1000);
    while(Serial1.available()){
        resp=Serial1.readString();

    }

}

String get_resp()
{String data;
    delay(500);
    if(Serial1.available()){
        data=Serial1.readString();

    }
    return data;
}

int8_t sendATcommand(char* ATcommand, char* expected_answer, unsigned int timeout){

    uint8_t x=0,  answer=0;
    char response[100];
    unsigned long previous;
    memset(response, '\0', 100);    

    delay(100);

    while( Serial1.available() > 0) Serial1.read();    
    if (ATcommand[0] != '\0')
    {
        Serial1.println(ATcommand);    
    }
    x = 0;
    previous = millis();

    
    do{
        if(Serial1.available() != 0){    
            response[x] = Serial1.read();
            
            x++;
            if (strstr(response, expected_answer) != NULL)    
            {
                answer = 1;
            }
        }
    }while((answer == 0) && ((millis() - previous) < timeout));    
    return answer;
}

void sim808_init(void){
    int i=0;
    while(!sendATcommand("AT\n\r", "OK", 1000)&&(i<5))
    {
        i++;
#ifdef DEBUG
        Serial.println("error!!");
#endif
                delay(1000);
    }

#ifdef DEBUG
    Serial.println("SIM connect!!");
#endif
    delay(1000);
    while(!sendATcommand("AT +CGNSPWR =1", "OK", 1000)&&(i<5))
    {
#ifdef DEBUG
        Serial.println("Mo GPS that bai");
#endif
        i++;
        delay(1000);
    }
#ifdef DEBUG
    Serial.println("Mo GPS thanh cong");
#endif
    while(!sendATcommand("AT+CGNSSEQ=\"RMC\"\r", "OK", 1000)&&(i<5))
    {
#ifdef DEBUG
        Serial.println("Dinh dang ban tin GPS that bai");
#endif
        i++;
        delay(1000);}
#ifdef DEBUG
    Serial.println("Dinh dang ban tin GPS thanh cong");
#endif
}



void convert_gps(GPS_T * gps_data,char* data)
{
    String date_time;
    strtok(data,",");
    gps_data->State_gps=atof(strtok(NULL,","));
    date_time=strtok(NULL,",");
    gps_data->Lat=strtok(NULL,",");
    gps_data->Lng=strtok(NULL,",");
    gps_data->time_gps.year=date_time.substring(0,4);
    gps_data->time_gps.month=date_time.substring(4,6);
    gps_data->time_gps.date=date_time.substring(6,8);
    gps_data->time_gps.hour=date_time.substring(8,10);
    gps_data->time_gps.minute=date_time.substring(10,12);
    gps_data->time_gps.sec=date_time.substring(12,14);
}
String conv_TimeGps(GPS_T *gps_data){
    return gps_data->time_gps.hour+":"+gps_data->time_gps.minute+":"+gps_data->time_gps.sec+" "
            +gps_data->time_gps.date+"/"+gps_data->time_gps.month+"/"+gps_data->time_gps.year;
}
void get_GPS(void){
    Send_cmd("AT+CGNSINF",data_resp);
    char resp[300];
    data_resp.toCharArray(resp,100);
    convert_gps(&g_gps_data, resp);

#ifdef DEBUG
    Serial.println(g_gps_data.State_gps);
    Serial.println(g_gps_data.time_gps.hour+":"+g_gps_data.time_gps.minute+":"
                   +g_gps_data.time_gps.sec+"/"+g_gps_data.time_gps.date+"/"
                   +g_gps_data.time_gps.month+"/"+g_gps_data.time_gps.year);
    Serial.println(g_gps_data.Lat);
    Serial.println(g_gps_data.Lng);
#endif

}

void sendSMS(char* phone,String SMS){








    char cmd[20];
    Serial.print("Setting SMS mode...");
    sendATcommand("AT+CMGF=1", "OK", 1000);    
    Serial.println("Sending SMS");

    sprintf(cmd,"AT+CMGS=\"%s\"", phone);
    Serial.println(cmd);

   
    if (sendATcommand(cmd, ">", 1000))
    {
        Serial1.print(SMS);
        Serial1.write(0x1A);

        if (sendATcommand("", "OK", 2000))
        {
            Serial.print("sent completed ");
        }
        else
        {
            Serial.print("error ");
        }

    }
    else
    {
        Serial.print("error ");
    }

}

void serialEvent(){
    String req;
    while(Serial.available())
    {
        req= Serial.readString();
    }
    if(req=="a")
    {
        get_GPS();

        String date_time=conv_TimeGps( &g_gps_data);
        Serial.println(date_time);
        String msg="Tin nhan bao vi tri thiet bi \n\r"+date_time+" Map:http://maps.google.com/maps?q="+g_gps_data.Lat+","+g_gps_data.Lng;
        sendSMS(phone_number , msg);

    }
    if(req=="b")
    {

    }
}




